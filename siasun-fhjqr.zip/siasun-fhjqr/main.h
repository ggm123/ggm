/*
 * main.h
 *
 *  Created on: Jun 24, 2019
 *      Author: siasunhebo
 */

#ifndef MAIN_H_
#define MAIN_H_

#include <can.h>

#endif /* MAIN_H_ */
